type Person = {
    firstName: string;
    lastName: string;
    age?: number;
    email?: string;
};

export type {
    Person
};